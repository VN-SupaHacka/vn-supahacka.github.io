#!/usr/bin/bash

if [ ! -f "./bin/decompressbip" ]; then
    echo "Compilando 'bin/decompressbip'"
    gcc ./src/decompressbip.c ./src/lzss.c -s -O3 -o ./bin/decompressbip
fi
if [ ! -f "./bin/compressbip" ]; then
    echo "Compilando 'bin/compressbip'"
    gcc ./src/compressbip.c ./src/lzss.c -s -O3 -o ./bin/compressbip
fi
if [ ! -f "./bin/repack_afs" ]; then
    echo "Compilando 'bin/repack_afs'"
    gcc ./src/repack_afs.c ./src/lzss.c -s -O3 -o ./bin/repack_afs
fi

if ! which "7z"; then
    echo "'7z' não encontrado, instalando.."
    sudo apt install 7zip
fi
if ! which "mkisofs"; then
    echo "'mkisofs' não encontrado, instalando.."
    sudo apt install genisoimage
fi
if ! which "xdelta3"; then
    echo "'xdelta3' não encontrado, instalando..."
    sudo apt install xdelta3
fi

echo "1. Extraindo arquivos da imagem ISO."
rm -rf ./iso_extracted
7z x ./Remember11-jap.iso -o"iso_extracted"

rm -rf ./tmp
mkdir ./tmp
mkdir ./tmp/mac-en/

echo "2. Realizando patch dos Textos das Cenas."
echo "- Descomprimindo mac.afs."
./bin/repack_afs ./iso_extracted/PSP_GAME/USRDIR/mac.afs ./tmp/mac.afs /dev/null ./tmp/mac >/dev/null 2>&1

echo "- Realizando patch dos arquivos de script."

patch_bip() {
    ./bin/decompressbip ./tmp/mac/$1.BIP ./tmp/mac/$1.SCN > /dev/null
    xdelta3 -f -d -s ./tmp/mac/$1.SCN ./xdelta3/mac/$1.SCN.xdelta3 ./tmp/mac-en/$1.SCN > /dev/null
    ./bin/compressbip ./tmp/mac-en/$1.SCN ./tmp/mac-en/$1.BIP > /dev/null
}

scripts=("CO1_01" "CO1_02" "CO1_03" "CO1_04" "CO1_05" "CO1_06" "CO1_07" "CO1_08" "CO1_09" "CO1_10" "CO1_11" "CO1_12" "CO1_13"
         "CO2_01" "CO2_02" "CO2_03" "CO2_04" "CO2_05" "CO2_06" "CO2_07" "CO2_08" "CO2_09A" "CO2_09B" "CO2_10" "CO2_11" "CO2_12"
         "CO3_01" "CO3_02" "CO3_03" "CO3_04" "CO3_05" "CO3_06" "CO3_07" "CO3_08" "CO3_09" "CO3_10"
         "CO4_01" "CO4_02" "CO4_03" "CO4_04" "CO4_05" "CO4_06" "CO4_07" "CO4_08" "CO4_09"
         "CO5_01" "CO5_02" "CO5_03" "CO5_04" "CO5_05" "CO5_06" "CO5_07" "CO5_08" "CO5_09" "CO5_10" "CO5_11" "CO5_12" "CO5_13"
         "CO6_01" "CO6_02" "CO6_03" "CO6_04" "CO6_05"
         "CO7_01" "CO7_02" "CO7_03" "CO7_04" "CO7_05" "CO7_06" "CO7_07"
         "COEP_01" "PR_01" "PR_02" "PR_03"
         "SA1_01" "SA1_02" "SA1_03" "SA1_04" "SA1_05" "SA1_06" "SA1_07" "SA1_08" "SA1_09"
         "SA2_01" "SA2_02" "SA2_03" "SA2_04" "SA2_05" "SA2_06" "SA2_07" "SA2_08" "SA2_09" "SA2_10" "SA2_11" "SA2_12" "SA2_13" "SA2_14" "SA2_15"
         "SA3_01" "SA3_02" "SA3_03" "SA3_04" "SA3_05" "SA3_06" "SA3_07" "SA3_08" "SA3_09" "SA3_10" "SA3_11" "SA3_12" "SA3_13" "SA3_14" "SA3_15"
         "SA4_01" "SA4_02" "SA4_03" "SA4_04" "SA4_05" "SA4_06" "SA4_07" "SA4_08" "SA4_09" "SA4_10" "SA4_11" "SA4_12" "SA4_13"
         "SA5_01" "SA5_02" "SA5_03" "SA5_04" "SA5_05" "SA5_06" "SA5_07" "SA5_08" "SA5_09"
         "SA6_01" "SA6_02" "SA6_03" "SA6_04" "SA6_05"
         "SA7_01" "SA7_02" "SA7_03" "SA7_04" "SA7_05" "SA7_06" "SA7_07" "SA7_08" "SA7_09"
         "SAEP_01" "SAEP_02" "SAEP_03" "SAEP_04" "SAEP_05" "SAEP_06")

for script in "${scripts[@]}"; do
    patch_bip $script
    echo "-> $script"
done

echo "- Feito"
echo "Remontando mac.afs com os arquivos modificados"

./bin/repack_afs ./iso_extracted/PSP_GAME/USRDIR/mac.afs ./tmp/mac.afs ./tmp/mac-en > /dev/null

echo "3. Aplicando o patch em etc.afs (Onde fica a fonte do jogo)"
./bin/repack_afs ./iso_extracted/PSP_GAME/USRDIR/etc.afs tmp/etc.afs.jp /dev/null ./tmp/etc > /dev/null 2>&1
./bin/decompressbip ./tmp/etc/FONT00.FOP ./tmp/etc/FONT00.FNT > /dev/null

mkdir ./tmp/etc-en
xdelta3 -f -d -s ./tmp/etc/FONT00.FNT ./xdelta3/FONT00.FNT.xdelta3 ./tmp/etc-en/FONT00.FNT
./bin/compressbip ./tmp/etc-en/FONT00.FNT ./tmp/etc-en/FONT00.FOP > /dev/null
./bin/repack_afs ./iso_extracted/PSP_GAME/USRDIR/etc.afs ./tmp/etc.afs ./tmp/etc-en > /dev/null

echo "4. Aplicando patch em init.bin (Glossário e outros)"
./bin/decompressbip ./iso_extracted/PSP_GAME/USRDIR/init.bin ./tmp/init.dec > /dev/null
xdelta3 -f -d -s ./tmp/init.dec ./xdelta3/init.dec.xdelta3 ./tmp/init.dec.en
./bin/compressbip ./tmp/init.dec.en ./tmp/init.bin > /dev/null

echo "5. Aplicando patches em BOOT.BIN (Texto de menus e modificações no binário)"
xdelta3 -f -d -s ./iso_extracted/PSP_GAME/SYSDIR/BOOT.BIN ./xdelta3/BOOT.BIN.xdelta3 ./tmp/BOOT.BIN

echo "6. Criando a nova imagem ISO"
cp ./tmp/BOOT.BIN ./iso_extracted/PSP_GAME/SYSDIR/EBOOT.BIN
mv ./tmp/BOOT.BIN ./iso_extracted/PSP_GAME/SYSDIR/BOOT.BIN
mv ./tmp/init.bin ./iso_extracted/PSP_GAME/USRDIR/init.bin
mv ./tmp/mac.afs ./iso_extracted/PSP_GAME/USRDIR/mac.afs
mv ./tmp/etc.afs ./iso_extracted/PSP_GAME/USRDIR/etc.afs

mkisofs -quiet -iso-level 4 -xa -A "PSP_GAME" -V "R11" -sysid "PSP GAME" -volset "" -p "" -publisher "" -o Remember11-ptbr-v1.iso iso_extracted

echo "Apagando arquivos temporários"
rm -rf ./iso_extracted
rm -rf ./tmp
echo "Patch PT-BR do Remember11 aplicado com sucesso, tenha um bom jogo!"
